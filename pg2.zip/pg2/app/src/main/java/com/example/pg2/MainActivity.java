package com.example.pg2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    ImageButton i1;
    Switch s1;
    ConstraintLayout c1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        i1=findViewById(R.id.imageButton);
        s1=findViewById(R.id.switch1);
        c1=findViewById(R.id.constraintLayout);
        DatePicker daye=new DatePicker(this);
        c1.addView(daye);
        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    i1.setEnabled(false);
                    c1.removeView(daye);
                }
                else {
                    i1.setEnabled(true);
                    c1.addView(daye);


                }
            }
        });
    }
}